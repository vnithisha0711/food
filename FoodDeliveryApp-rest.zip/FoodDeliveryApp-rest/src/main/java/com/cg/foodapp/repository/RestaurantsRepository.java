package com.cg.foodapp.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.foodapp.entity.Restaurants;
import com.cg.foodapp.entity.User;

@Repository
public interface RestaurantsRepository extends CrudRepository<Restaurants, Integer>{

	Iterable<Restaurants> findAll();

	User save(User user);
}
