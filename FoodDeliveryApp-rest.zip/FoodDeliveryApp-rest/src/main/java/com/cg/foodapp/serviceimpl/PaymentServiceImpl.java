package com.cg.foodapp.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.foodapp.dto.PaymentDTO;
import com.cg.foodapp.entity.Payment;
import com.cg.foodapp.exceptions.PaymentDeclineException;
import com.cg.foodapp.repository.PaymentRepository;
import com.cg.foodapp.service.PaymentService;

@Service
public class PaymentServiceImpl implements PaymentService {

	@Autowired
	public PaymentRepository repository;

	@Override
	public Payment addPayment(Payment payment) {

		Payment addpayment = repository.save(payment);
		//BeanUtils.copyProperties(paymentDTO, payment);
		return addpayment;
	}

	@Override
	public PaymentDTO getById(int id) {

		Optional<Payment> payment = repository.findById(id);
		if (payment.isPresent()) {
			PaymentDTO dto = new PaymentDTO();
			BeanUtils.copyProperties(payment.get(), dto);
			return dto;
		}
		throw new PaymentDeclineException("Payment not Available at this time");
	}

	@Override
	public List<PaymentDTO> findAll() {

		Iterable<Payment> payment = repository.findAll();
		List<PaymentDTO> dtos = new ArrayList<>();
		for (Payment payments : payment) {
			PaymentDTO dto = new PaymentDTO();
			BeanUtils.copyProperties(payments, dto);
			dtos.add(dto);
		}
		return dtos;
	}

}
