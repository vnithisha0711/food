package com.cg.foodapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.foodapp.dto.CartDTO;
import com.cg.foodapp.dto.CustomersDTO;
import com.cg.foodapp.dto.FoodItemsDTO;
import com.cg.foodapp.dto.RestaurantsDTO;
import com.cg.foodapp.service.FoodService;

@RestController
@RequestMapping("/api/food-service")
public class FoodServiceController {

	@Autowired
	public FoodService foodService;

	@PutMapping("/updateFoodItems")
	public ResponseEntity<FoodItemsDTO> updateFoodItems(@RequestBody FoodItemsDTO foodItemsDTO) {
		return new ResponseEntity<FoodItemsDTO>(foodService.updateFoodItems(foodItemsDTO), HttpStatus.ACCEPTED);

	}
	
	@PostMapping("/addCustomers")
	public ResponseEntity<CustomersDTO> addCustomers(@RequestBody CustomersDTO customersDTO) {

		foodService.addCustomers(customersDTO);
		return ResponseEntity.ok(customersDTO);

	}

	@PostMapping("/addRestaurants")
	public ResponseEntity<RestaurantsDTO> addRestaurants(@RequestBody RestaurantsDTO restaurantsDTO) {

		foodService.addRestaurants(restaurantsDTO);
		return ResponseEntity.ok(restaurantsDTO);

	}

	@PostMapping("/addFoodItems")
	public ResponseEntity<FoodItemsDTO> addFoodItems(@RequestBody FoodItemsDTO foodItemsDTO) {

		foodService.addFoodItems(foodItemsDTO);
		return ResponseEntity.ok(foodItemsDTO);

	}

	@PostMapping("/cart")
	public ResponseEntity<CartDTO> addItemsInCart(@RequestBody CartDTO cartDTO) {
		foodService.addItemsInCart(cartDTO);
		return ResponseEntity.ok(cartDTO);
	}

	@GetMapping
	public ResponseEntity<List<FoodItemsDTO>> getAllFoodItems() {
		List<FoodItemsDTO> list = foodService.findAll();
		return ResponseEntity.ok(list);
	}
	


	@DeleteMapping("/fooditems/{id}")
	public boolean deleteFoodItems(@PathVariable int id) {
		FoodItemsDTO foodItemsDTO = foodService.getById(id);
		return foodService.deleteFoodItems(foodItemsDTO);
	}
}
