package com.cg.foodapp.service;

import java.util.List;

import com.cg.foodapp.dto.CartDTO;


public interface CartService {

	public CartDTO addToCart(CartDTO cartDTO);

	public CartDTO updateCart(CartDTO cartDTO);

	public boolean deleteCart(CartDTO cartDTO);

	public CartDTO getById(int id);

	public List<CartDTO> findAll();
}
