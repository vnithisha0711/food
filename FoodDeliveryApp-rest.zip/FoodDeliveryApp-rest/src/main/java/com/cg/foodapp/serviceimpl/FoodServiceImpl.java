package com.cg.foodapp.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.foodapp.dto.CartDTO;
import com.cg.foodapp.dto.CustomersDTO;
import com.cg.foodapp.dto.FoodItemsDTO;
import com.cg.foodapp.dto.RestaurantsDTO;
import com.cg.foodapp.entity.Cart;
import com.cg.foodapp.entity.Customers;
import com.cg.foodapp.entity.FoodItems;
import com.cg.foodapp.entity.Restaurants;
import com.cg.foodapp.repository.CartRepository;
import com.cg.foodapp.repository.CustomersRepository;
import com.cg.foodapp.repository.FoodItemsRepository;
import com.cg.foodapp.repository.RestaurantsRepository;
import com.cg.foodapp.service.FoodService;

@Service
public class FoodServiceImpl implements FoodService {

	@Autowired
	private CustomersRepository customersRepository;
	
	@Autowired
	private RestaurantsRepository restaurantsRepository;
	
	@Autowired
	private FoodItemsRepository foodItemsRepository;
	
	@Autowired
	private CartRepository cartRepository;

	@Override
	public CustomersDTO addCustomers(CustomersDTO customersDTO) {

		Customers customers = new Customers();
		BeanUtils.copyProperties(customersDTO, customers);
		customersRepository.save(customers);
		return customersDTO;

	}

	@Override
	public RestaurantsDTO addRestaurants(RestaurantsDTO restaurantsDTO) {
		
		Restaurants restaurants = new Restaurants();
		BeanUtils.copyProperties(restaurantsDTO, restaurants);
		restaurantsRepository.save(restaurants);
		return restaurantsDTO;
	}

	@Override
	public FoodItemsDTO addFoodItems(FoodItemsDTO foodItemsDTO) {
		
		FoodItems foodItems = new FoodItems();
		BeanUtils.copyProperties(foodItemsDTO, foodItems);
		foodItemsRepository.save(foodItems);
		return foodItemsDTO;
	}

	@Override
	public CartDTO addItemsInCart(CartDTO cartDTO) {
		
		int customerId = cartDTO.getCustomerId();
		int foodId = cartDTO.getFoodId();
		Customers c = customersRepository.findById(customerId).get();
		FoodItems f = foodItemsRepository.findById(foodId).get();
		Cart cart = new Cart();
		cart.setCustomers(c);
		cart.setFooditems(f);
		cart.setQuantity(cartDTO.getQuantity());
		cart = cartRepository.save(cart);
		
		if(cart.getId() != 0) {
			cartDTO.setCartId(cart.getId());
		}
		else {
			cartDTO.setCartId(0);
			
		}
		return cartDTO;
	}

	@Override
	public List<FoodItemsDTO> findAll() {
		
		 Iterable<FoodItems> list = foodItemsRepository.findAll();
	        List<FoodItemsDTO> dtos=new ArrayList<>();
	        for(FoodItems fooditems:list) {
	            FoodItemsDTO dto=new FoodItemsDTO();
	            BeanUtils.copyProperties(fooditems, dto);
	            dtos.add(dto);
	        }
	        return dtos;
	}

	@Override
	public boolean deleteFoodItems(FoodItemsDTO foodItemsDTO) {
		
		FoodItems fooditems = new FoodItems(); 
        BeanUtils.copyProperties(foodItemsDTO, fooditems);
        foodItemsRepository.delete(fooditems);
        return true;
	}

	@Override
	public FoodItemsDTO getById(int id) {
		
		Optional<FoodItems> fooditems = foodItemsRepository.findById(id);
        if(fooditems.isPresent()) {
            
            FoodItemsDTO dto=new FoodItemsDTO();
            BeanUtils.copyProperties(fooditems.get(), dto);
            return dto;
   
        }
        return null;
    }


	@Override
	public FoodItemsDTO updateFoodItems(FoodItemsDTO foodItemsDTO) {
		
		FoodItems foodItems = new FoodItems(); 
        BeanUtils.copyProperties(foodItemsDTO, foodItems);
        foodItemsRepository.save(foodItems);
        return foodItemsDTO;
	}

}
