package com.cg.foodapp.service;

import java.util.List;

import com.cg.foodapp.dto.UserDTO;

public interface UserService {

	public UserDTO addUser(UserDTO userDTO);

	public UserDTO updateUser(UserDTO userDTO);

	public boolean deleteUser(UserDTO userDTO);

	public UserDTO getById(int id);

	public List<UserDTO> findAll();
}
