package com.cg.foodapp.service;

import java.util.List;
import com.cg.foodapp.dto.PaymentDTO;
import com.cg.foodapp.entity.Payment;

public interface PaymentService {

	public Payment addPayment(Payment payment);

	public PaymentDTO getById(int id);

	public List<PaymentDTO> findAll();

}
