package com.cg.foodapp.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.foodapp.dto.FoodItemsDTO;
import com.cg.foodapp.entity.FoodItems;
import com.cg.foodapp.entity.Restaurants;
import com.cg.foodapp.repository.FoodItemsRepository;
import com.cg.foodapp.repository.RestaurantsRepository;
import com.cg.foodapp.service.FoodItemsService;

@Service
public class FoodItemsServiceImpl implements FoodItemsService {
	@Autowired
	private FoodItemsRepository foodItemsRepository;

	

	@Override
	public FoodItemsDTO addFoodItems(FoodItemsDTO foodItemsDTO) {


		FoodItems Fooditems = new FoodItems();
		BeanUtils.copyProperties(foodItemsDTO, Fooditems);
		
		foodItemsRepository.save(Fooditems);
		return foodItemsDTO;
	}

	@Override
	public FoodItemsDTO updateFoodItems(FoodItemsDTO foodItemsDTO) {

		FoodItems Fooditems = new FoodItems();
		BeanUtils.copyProperties(foodItemsDTO, Fooditems);
		foodItemsRepository.save(Fooditems);
		return foodItemsDTO;
	}

	@Override
	public boolean deleteFoodItems(FoodItemsDTO foodItemsDTO) {

		FoodItems Fooditems = new FoodItems();
		BeanUtils.copyProperties(foodItemsDTO, Fooditems);
		foodItemsRepository.delete(Fooditems);
		return true;
	}

	@Override
	public FoodItemsDTO getById(int id) {

		Optional<FoodItems> fooditems = foodItemsRepository.findById(id);
		if (fooditems.isPresent()) {
			FoodItemsDTO dto = new FoodItemsDTO();
			BeanUtils.copyProperties(fooditems.get(), dto);
			return dto;
		}
		return null;
	}

	@Override
	public List<FoodItemsDTO> findAll() {

		Iterable<FoodItems> fooditems = foodItemsRepository.findAll();
		List<FoodItemsDTO> dtos = new ArrayList<>();
		for (FoodItems fooditem : fooditems) {
			FoodItemsDTO dto = new FoodItemsDTO();
			BeanUtils.copyProperties(fooditem, dto);
			dtos.add(dto);
		}
		return dtos;
	}

}
