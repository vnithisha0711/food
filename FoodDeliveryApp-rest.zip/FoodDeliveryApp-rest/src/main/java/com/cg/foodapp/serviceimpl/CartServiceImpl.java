package com.cg.foodapp.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.foodapp.dto.CartDTO;
import com.cg.foodapp.entity.Cart;
import com.cg.foodapp.repository.CartRepository;
import com.cg.foodapp.service.CartService;

@Service
public class CartServiceImpl implements CartService {

	@Autowired
	private CartRepository cartRepository;

	@Override
	public CartDTO addToCart(CartDTO cartDTO) {

		Cart cart = new Cart();
		BeanUtils.copyProperties(cartDTO, cart);
		cartRepository.save(cart);
		return cartDTO;
	}

	@Override
	public CartDTO updateCart(CartDTO cartDTO) {
		Cart cart = new Cart();
		BeanUtils.copyProperties(cartDTO, cart);
		cartRepository.save(cart);
		return cartDTO;
	}

	@Override
	public boolean deleteCart(CartDTO cartDTO) {
		Cart cart = new Cart();
		BeanUtils.copyProperties(cartDTO, cart);
		cartRepository.delete(cart);
		return true;
	}

	@Override
	public CartDTO getById(int id) {

		Optional<Cart> cart = cartRepository.findById(id);
		if (cart.isPresent()) {
			CartDTO dto = new CartDTO();
			BeanUtils.copyProperties(cart.get(), dto);
			return dto;
		}
		return null;
	}

	@Override
	public List<CartDTO> findAll() {

		Iterable<Cart> cart = cartRepository.findAll();
		List<CartDTO> dtos = new ArrayList<>();
		for (Cart carts : cart) {
			CartDTO dto = new CartDTO();
			BeanUtils.copyProperties(carts, dto);
			dtos.add(dto);
		}
		return dtos;
	}

}
