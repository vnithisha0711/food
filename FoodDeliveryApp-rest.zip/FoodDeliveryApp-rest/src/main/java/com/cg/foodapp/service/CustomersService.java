package com.cg.foodapp.service;

import java.util.List;

import com.cg.foodapp.dto.CustomersDTO;
import com.cg.foodapp.entity.Customers;

public interface CustomersService {

	public CustomersDTO addCustomers(CustomersDTO customers);

	public CustomersDTO updateCustomers(CustomersDTO customersDTO);

	public boolean deleteCustomers(CustomersDTO customersDTO);

	public CustomersDTO getById(int id);

	public List<CustomersDTO> findAll();
}
