package com.cg.foodapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.foodapp.dto.UserDTO;
import com.cg.foodapp.exceptions.ItemNotAvailableException;
import com.cg.foodapp.service.UserService;
@RestController
@RequestMapping("/api/user")
public class UserController {

	@Autowired
	public UserService userService;
	
	@PostMapping("/addUser")
	public ResponseEntity<UserDTO> addUser(@RequestBody UserDTO userDTO){
		
			UserDTO user = userService.addUser(userDTO);
			return ResponseEntity.ok(user);
		
	}

	@GetMapping("/{id}")
	public ResponseEntity<UserDTO> getUserById(@PathVariable int id){
		UserDTO userDTO=userService.getById(id);
		return new ResponseEntity<UserDTO>(userDTO, HttpStatus.FOUND);
	}
	
	@PutMapping
	public ResponseEntity<UserDTO> updateUser(@RequestBody UserDTO userDTO){
		return new ResponseEntity<UserDTO>(userService.updateUser(userDTO), HttpStatus.ACCEPTED);
		
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Boolean> deleteUserById(@PathVariable int id){
		UserDTO userDTO=userService.getById(id);
		if(userDTO!=null) {
			userService.deleteUser(userDTO);
			return new ResponseEntity<Boolean>(true, HttpStatus.ACCEPTED);
		}
		throw new ItemNotAvailableException("Orders with id " +id+ "doesnot exists");
	}
	
	@GetMapping
	public ResponseEntity<List<UserDTO>> getAllUser(){
		List<UserDTO> list=userService.findAll();
		return ResponseEntity.ok(list);
	}
}
