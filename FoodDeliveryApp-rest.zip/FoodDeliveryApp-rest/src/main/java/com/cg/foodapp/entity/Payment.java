package com.cg.foodapp.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "payment_details")
public class Payment {

	private String paymentType;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int paymentId;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "customer_id")
	private Customers customers;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "order_id")
	private Orders orders;

	


	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

}
