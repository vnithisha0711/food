package com.cg.foodapp.dto;

public class PaymentDTO {

	private String paymentType;

	

	public PaymentDTO() {}

	public PaymentDTO(String paymentType) {
		super();
		this.paymentType = paymentType;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

}
