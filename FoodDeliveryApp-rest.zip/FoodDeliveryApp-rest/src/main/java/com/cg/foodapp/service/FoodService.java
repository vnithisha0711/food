package com.cg.foodapp.service;

import java.util.List;

import com.cg.foodapp.dto.CartDTO;
import com.cg.foodapp.dto.CustomersDTO;
import com.cg.foodapp.dto.FoodItemsDTO;
import com.cg.foodapp.dto.RestaurantsDTO;

public interface FoodService {

	public FoodItemsDTO updateFoodItems(FoodItemsDTO foodItemsDTO);
	
	public CustomersDTO addCustomers(CustomersDTO customersDTO);
	
	public RestaurantsDTO addRestaurants(RestaurantsDTO restaurantsDTO);
	
    public FoodItemsDTO addFoodItems(FoodItemsDTO foodItemsDTO);
    
    public CartDTO addItemsInCart(CartDTO cartDTO);
    
    public List<FoodItemsDTO> findAll();
    
    public boolean deleteFoodItems(FoodItemsDTO foodItemsDTO);
    
    public FoodItemsDTO getById(int id);
	
}
